import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { once } from "node:events";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import net from "node:net";

async function freePort() {
  const server = net.createServer();
  server.listen(0, "127.0.0.1");
  await once(server, "listening");
  const port = server.address().port;
  await new Promise(resolve => server.close(resolve));
  return port;
}
test("health, provider status, validation, and story library endpoints", async (t) => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "ezstory-test-"));
  const port = await freePort();
  const child = spawn(process.execPath, ["server.js"], {
    cwd: process.cwd(),
    env: { ...process.env, PORT: String(port), NODE_ENV: "test", DB_PATH: path.join(tmp, "test.sqlite"), SESSION_SECRET: "test-secret-at-least-thirty-two-characters-long", OPENAI_API_KEY: "", ANTHROPIC_API_KEY: "", GEMINI_API_KEY: "", DEEPSEEK_API_KEY: "", DOUBAO_API_KEY: "", DOUBAO_MODEL: "" },
    stdio: "ignore"
  });
  t.after(() => { child.kill("SIGTERM"); fs.rmSync(tmp, { recursive: true, force: true }); });
  let ready = false;
  for (let i = 0; i < 60; i++) {
    try { const r = await fetch(`http://127.0.0.1:${port}/api/health`); if (r.ok) { ready = true; break; } } catch {}
    await new Promise(r => setTimeout(r, 100));
  }
  assert.equal(ready, true, "server should start");
  const base = `http://127.0.0.1:${port}`;
  let r = await fetch(base + "/api/health"); assert.equal(r.status, 200);
  r = await fetch(base + "/api/providers"); const p = await r.json(); assert.equal(r.status, 200);
  assert.equal(p.providers.openai.configured, false);
  assert.equal(JSON.stringify(p).includes("API_KEY"), false, "provider status must not expose secrets");
  r = await fetch(base + "/api/generate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ provider: "openai", task: "story", prompt: "test prompt" }) });
  assert.equal(r.status, 503, "unconfigured provider should fail clearly");
  r = await fetch(base + "/api/stories", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: "Test story", story: "A short test story.", genre: "Drama", language: "English" }) });
  assert.equal(r.status, 201);
  const saved = await r.json(); assert.ok(saved.story.id);
  const cookie = r.headers.get("set-cookie"); assert.ok(cookie && cookie.includes("HttpOnly"));
  const cookieHeader = cookie.split(";")[0];
  r = await fetch(base + "/api/stories", { headers: { Cookie: cookieHeader } });
  const list = await r.json(); assert.equal(list.stories.length, 1);
  r = await fetch(base + "/api/stories/" + saved.story.id, { headers: { Cookie: cookieHeader } });
  assert.equal(r.status, 200);
  r = await fetch(base + "/api/stories/" + saved.story.id, { method: "DELETE", headers: { Cookie: cookieHeader } });
  assert.equal(r.status, 200);
  r = await fetch(base + "/api/stories/" + saved.story.id, { headers: { Cookie: cookieHeader } });
  assert.equal(r.status, 404);
});
