# EZStoryByClingyAi — Full-stack v2

A secure-backend version of the supplied HTML prototype.

## Requirements
- Node.js 20.11+
- npm
- API credentials for any hosted AI provider you want to use

## Local run
1. Copy `.env.example` to `.env`.
2. Set `SESSION_SECRET` to a random secret (32+ characters) and configure at least one provider key.
3. Install dependencies: `npm install`
4. Start: `npm start`
5. Open `http://localhost:3000`

The server loads `.env` automatically through `dotenv` for local development. Do not commit `.env`; it is excluded by `.gitignore`.

## Security notes
- Provider keys are read only from server environment variables. No API key field exists in the browser UI.
- A signed, HttpOnly, SameSite=Strict cookie associates a browser with its own library. In production the cookie is Secure.
- SQLite persists stories to `data/stories.sqlite` by default. Configure a persistent disk/volume and `DB_PATH` when hosting.
- API generation has per-IP rate limiting plus a per-browser-session usage counter. The built-in in-memory IP limiter is not shared between multiple server instances; use a shared rate-limit store (Redis or a managed equivalent) for scaled production.
- The anonymous session cookie is not a user account or cross-device login. Add proper authentication before treating this as an account-based product.
- Keep HTTPS enabled in production. Set `NODE_ENV=production`, `SESSION_SECRET`, provider keys, and persistent database storage.
- Consider a reverse proxy, billing/quota controls, backups, monitoring, and abuse detection before public launch.

## Provider configuration and compatibility
- OpenAI: `OPENAI_API_KEY`, `OPENAI_MODEL`, default `gpt-4o-mini`, `/v1/chat/completions`.
- Anthropic: `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL`, default `claude-sonnet-5-5`, `/v1/messages`.
- Gemini: `GEMINI_API_KEY`, `GEMINI_MODEL`, default `gemini-2.5-flash`, `models.generateContent` with JSON response mode.
- DeepSeek: `DEEPSEEK_API_KEY`, `DEEPSEEK_MODEL`, default `deepseek-flash`, OpenAI-compatible chat completions.
- Doubao/Ark: `DOUBAO_API_KEY`, `DOUBAO_MODEL` are required; default base URL is `https://ark.cn-beijing.volces.com/api/v3`. Model identifiers are deployment/account-specific; set the exact model/endpoint ID from the Ark console.
- Ollama: `OLLAMA_ENABLED=true`, `OLLAMA_MODEL`, `OLLAMA_BASE_URL`. The Ollama endpoint must be reachable from the server machine/container.
- Custom: `CUSTOM_API_KEY`, `CUSTOM_MODEL`, `CUSTOM_BASE_URL`, OpenAI-compatible chat-completions only.

A successful status check only means required environment variables exist. Use **Test selected provider** from the app to verify a real credential/model request. That requires provider credentials, outbound internet, provider quota, and the provider model being enabled for your account.

## API
- `GET /api/health`
- `GET /api/providers`
- `POST /api/generate` body `{ "provider":"openai", "task":"story|episodes|test", "prompt":"..." }`
- `POST /api/test-provider` body `{ "provider":"openai" }`
- `GET /api/stories`
- `POST /api/stories`
- `GET /api/stories/:id`
- `DELETE /api/stories/:id`

## Tests
Run `npm test`. Tests cover server health, API-key non-disclosure in provider status, input validation, library ownership separation, and rate limiting where practical. Live provider tests are intentionally not faked.


## Deploy publicly on Render (single instance)
1. Push this project to a private or public GitHub repository.
2. In Render, create a Blueprint from the repository and use `render.yaml`.
3. Set the AI provider keys and model variables in the Render service environment dashboard. Never add real keys to Git.
4. Render will provision a persistent disk at `/var/data` and the service is configured to use `/var/data/stories.sqlite`. Render provides HTTPS for the deployed `onrender.com` domain.
5. Check `/api/health`, then use **AI provider status → Test selected provider**.
6. Before enabling public traffic, review the request quota, provider spend limits, logs, backups, and privacy notice.

The included Render setup is a public single-instance launch. For horizontal scaling, use a shared PostgreSQL database for stories and `REDIS_URL` for rate limiting; the current SQLite database is deliberately not presented as multi-instance safe.
