import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import { RedisStore } from "rate-limit-redis";
import { createClient } from "redis";
import Database from "better-sqlite3";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === "production";
const SESSION_SECRET = process.env.SESSION_SECRET || (IS_PROD ? "" : "local-development-only-change-me");
if (IS_PROD && SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET must be set to a random value of at least 32 characters in production.");
  process.exit(1);
}
const COOKIE_NAME = "ezstory_session";
const MAX_INPUT_CHARS = Number(process.env.MAX_INPUT_CHARS || 20000);
const MAX_OUTPUT_TOKENS = Number(process.env.MAX_OUTPUT_TOKENS || 7000);
const dbPath = process.env.DB_PATH || path.join(__dirname, "data", "stories.sqlite");
import fs from "node:fs";
fs.mkdirSync(path.dirname(dbPath), { recursive: true });
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS stories (
 id TEXT PRIMARY KEY,
 owner_hash TEXT NOT NULL,
 title TEXT NOT NULL,
 logline TEXT NOT NULL DEFAULT '',
 genre TEXT NOT NULL DEFAULT '',
 language TEXT NOT NULL DEFAULT '',
 story TEXT NOT NULL,
 metadata_json TEXT NOT NULL DEFAULT '{}',
 created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS stories_owner_updated ON stories(owner_hash, updated_at DESC);
CREATE TABLE IF NOT EXISTS rate_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 owner_hash TEXT NOT NULL,
 kind TEXT NOT NULL,
 created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS rate_events_owner_time ON rate_events(owner_hash, created_at);
`);

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: "256kb", strict: true }));
app.use(express.urlencoded({ extended: false, limit: "16kb" }));

function b64url(buf) { return Buffer.from(buf).toString("base64url"); }
function signToken(token) { return crypto.createHmac("sha256", SESSION_SECRET).update(token).digest("base64url"); }
function safeEqual(a, b) {
  const aa = Buffer.from(String(a)); const bb = Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function ownerMiddleware(req, res, next) {
  const raw = req.headers.cookie || "";
  const cookies = Object.fromEntries(raw.split(";").map(s => s.trim()).filter(Boolean).map(s => {
    const i = s.indexOf("="); return i < 0 ? [s, ""] : [s.slice(0, i), decodeURIComponent(s.slice(i + 1))];
  }));
  let token = cookies[COOKIE_NAME] || "";
  const parts = token.split(".");
  if (parts.length !== 2 || !safeEqual(parts[1], signToken(parts[0])) || parts[0].length < 40) {
    const random = crypto.randomBytes(32).toString("base64url");
    token = random + "." + signToken(random);
    res.append("Set-Cookie", `${COOKIE_NAME}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=31536000${IS_PROD ? "; Secure" : ""}`);
  }
  const rawToken = token.split(".")[0];
  req.ownerHash = crypto.createHash("sha256").update(rawToken).digest("hex");
  next();
}
app.use(ownerMiddleware);

const providerDefaults = {
  openai: { configured: !!process.env.OPENAI_API_KEY, model: process.env.OPENAI_MODEL || "gpt-4o-mini", base: "https://api.openai.com/v1", kind: "openai" },
  claude: { configured: !!process.env.ANTHROPIC_API_KEY, model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5", kind: "claude" },
  gemini: { configured: !!process.env.GEMINI_API_KEY, model: process.env.GEMINI_MODEL || "gemini-2.5-flash", kind: "gemini" },
  deepseek: { configured: !!process.env.DEEPSEEK_API_KEY, model: process.env.DEEPSEEK_MODEL || "deepseek-flash", base: "https://api.deepseek.com", kind: "openai" },
  doubao: { configured: !!process.env.DOUBAO_API_KEY && !!process.env.DOUBAO_MODEL, model: process.env.DOUBAO_MODEL || "", base: process.env.DOUBAO_BASE_URL || "https://ark.cn-beijing.volces.com/api/v3", kind: "openai" },
  ollama: { configured: !!process.env.OLLAMA_ENABLED, model: process.env.OLLAMA_MODEL || "llama3.1", base: process.env.OLLAMA_BASE_URL || "http://127.0.0.1:11434/v1", kind: "openai", noKey: true },
  custom: { configured: !!process.env.CUSTOM_API_KEY && !!process.env.CUSTOM_BASE_URL && !!process.env.CUSTOM_MODEL, model: process.env.CUSTOM_MODEL || "", base: process.env.CUSTOM_BASE_URL || "", kind: "openai" }
};
function providerInfo(p) {
  const d = providerDefaults[p];
  if (!d) return null;
  return { configured: d.configured, model: d.model, kind: d.kind };
}
function getProvider(p) {
  const d = providerDefaults[p];
  if (!d) throw httpError(400, "Unsupported provider.");
  if (!d.configured) throw httpError(503, `${p} is not configured on this server.`);
  if (!d.model) throw httpError(503, `${p} has no model ID configured.`);
  const envKey = {
    openai: "OPENAI_API_KEY", claude: "ANTHROPIC_API_KEY", gemini: "GEMINI_API_KEY",
    deepseek: "DEEPSEEK_API_KEY", doubao: "DOUBAO_API_KEY", ollama: null, custom: "CUSTOM_API_KEY"
  }[p];
  return { ...d, key: envKey ? process.env[envKey] : "", name: p };
}
function httpError(status, message) { const e = new Error(message); e.status = status; return e; }

// Optional shared Redis store. Configure REDIS_URL before running multiple app instances.
let redisClient = null;
let redisReady = false;
if (process.env.REDIS_URL) {
  redisClient = createClient({ url: process.env.REDIS_URL });
  redisClient.on("error", (err) => console.error("[redis] connection error:", err.message));
  try {
    await redisClient.connect();
    redisReady = true;
    console.log("[redis] shared rate-limit store connected");
  } catch (err) {
    console.error("[redis] failed to connect; refusing to silently use per-instance rate limits:", err.message);
    if (IS_PROD) process.exit(1);
  }
}
const stores = new Map();
function rateStore(prefix) {
  if (!redisReady) return undefined;
  if (!stores.has(prefix)) stores.set(prefix, new RedisStore({ prefix, sendCommand: (...args) => redisClient.sendCommand(args) }));
  return stores.get(prefix);
}
if (IS_PROD && process.env.REQUIRE_SHARED_RATE_LIMIT_STORE === "true" && !redisReady) {
  console.error("REQUIRE_SHARED_RATE_LIMIT_STORE=true but REDIS_URL is unavailable.");
  process.exit(1);
}

const generateLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, limit: Number(process.env.GENERATE_LIMIT_PER_HOUR || 20),
  ...(rateStore("ezstory:generate:") ? { store: rateStore("ezstory:generate:") } : {}),
  standardHeaders: "draft-8", legacyHeaders: false,
  handler: (_req, res) => res.status(429).json({ error: "Generation limit reached. Please try again later." })
});
const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, ...(rateStore("ezstory:api:") ? { store: rateStore("ezstory:api:") } : {}), standardHeaders: "draft-8", legacyHeaders: false });
app.use("/api", apiLimiter);

function recordUsage(ownerHash, kind, limit, windowMs) {
  const now = Date.now();
  db.prepare("DELETE FROM rate_events WHERE created_at < ?").run(now - 24 * 60 * 60 * 1000);
  const row = db.prepare("SELECT COUNT(*) AS n FROM rate_events WHERE owner_hash=? AND kind=? AND created_at>?").get(ownerHash, kind, now - windowMs);
  if (row.n >= limit) throw httpError(429, `You have reached the ${kind} limit. Please try again later.`);
  db.prepare("INSERT INTO rate_events(owner_hash,kind,created_at) VALUES(?,?,?)").run(ownerHash, kind, now);
}
function requireString(value, name, max) {
  if (typeof value !== "string" || !value.trim()) throw httpError(400, `${name} is required.`);
  if (value.length > max) throw httpError(413, `${name} is too long (maximum ${max} characters).`);
  return value.trim();
}
async function providerRequest(provider, prompt) {
  const d = getProvider(provider);
  const timeout = AbortSignal.timeout(Number(process.env.PROVIDER_TIMEOUT_MS || 90000));
  let response;
  const headers = { "Content-Type": "application/json" };
  let url, body;
  if (d.kind === "claude") {
    url = "https://api.anthropic.com/v1/messages";
    headers["x-api-key"] = d.key; headers["anthropic-version"] = "2023-06-01";
    body = { model: d.model, max_tokens: MAX_OUTPUT_TOKENS, messages: [{ role: "user", content: prompt }] };
  } else if (d.kind === "gemini") {
    url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(d.model)}:generateContent?key=${encodeURIComponent(d.key)}`;
    body = { contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: "application/json", temperature: 0.7, maxOutputTokens: MAX_OUTPUT_TOKENS } };
  } else {
    url = `${d.base.replace(/\/+$/, "")}/chat/completions`;
    if (d.key) headers.Authorization = `Bearer ${d.key}`;
    body = { model: d.model, messages: [{ role: "user", content: prompt }], temperature: 0.7, response_format: { type: "json_object" }, max_tokens: MAX_OUTPUT_TOKENS };
  }
  try {
    response = await fetch(url, { method: "POST", headers, body: JSON.stringify(body), signal: timeout });
  } catch (e) {
    if (e.name === "TimeoutError" || e.name === "AbortError") throw httpError(504, "The AI provider timed out. Try a shorter prompt or retry.");
    throw httpError(502, "Could not connect to the AI provider. Check the server's internet access and provider configuration.");
  }
  if (!response.ok) {
    const details = (await response.text().catch(() => "")).slice(0, 500);
    const status = response.status === 429 ? 429 : response.status >= 500 ? 502 : 502;
    const message = response.status === 401 || response.status === 403
      ? "The AI provider rejected the server credentials. Check the configured API key and permissions."
      : response.status === 404 ? "The model or endpoint was not found. Check the provider model ID and base URL."
      : response.status === 429 ? "The AI provider rate limit or quota was reached. Wait and try again."
      : `The AI provider returned HTTP ${response.status}.`;
    console.warn(`[provider:${provider}] HTTP ${response.status}: ${details}`);
    throw httpError(status, message);
  }
  let json;
  try { json = await response.json(); } catch { throw httpError(502, "The AI provider returned an invalid response."); }
  let output = "";
  if (d.kind === "claude") output = (json.content || []).map(x => x.text || "").join("\n");
  else if (d.kind === "gemini") output = (((json.candidates || [])[0] || {}).content?.parts || []).map(x => x.text || "").join("\n");
  else output = json.choices?.[0]?.message?.content || "";
  output = output.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  const first = output.indexOf("{"), last = output.lastIndexOf("}");
  if (first < 0 || last < first) throw httpError(502, "The AI response did not contain JSON. Please retry.");
  try { return JSON.parse(output.slice(first, last + 1)); }
  catch { throw httpError(502, "The AI returned malformed JSON. Please retry."); }
}

app.get("/api/health", (_req, res) => res.json({ ok: true }));
app.get("/api/providers", (_req, res) => {
  const providers = {};
  for (const p of Object.keys(providerDefaults)) providers[p] = providerInfo(p);
  res.json({ providers });
});
app.post("/api/generate", generateLimiter, async (req, res, next) => {
  try {
    const provider = requireString(req.body.provider, "Provider", 30);
    const task = requireString(req.body.task, "Task", 30);
    const prompt = requireString(req.body.prompt, "Prompt", MAX_INPUT_CHARS + 12000);
    if (!["story", "episodes", "test"].includes(task)) throw httpError(400, "Unsupported generation task.");
    if (prompt.length > MAX_INPUT_CHARS + 12000) throw httpError(413, "Prompt is too long.");
    recordUsage(req.ownerHash, "generation", Number(process.env.GENERATE_LIMIT_PER_HOUR || 20), 60 * 60 * 1000);
    const result = await providerRequest(provider, prompt);
    res.json({ result });
  } catch (e) { next(e); }
});
app.post("/api/test-provider", async (req, res, next) => {
  try {
    const provider = requireString(req.body.provider, "Provider", 30);
    recordUsage(req.ownerHash, "provider-test", 8, 60 * 60 * 1000);
    const result = await providerRequest(provider, 'Return ONLY valid JSON: {"ok":true,"message":"connection works"}');
    if (result.ok !== true) throw httpError(502, "Provider responded, but the test payload was not valid.");
    res.json({ ok: true, message: "Connection test succeeded." });
  } catch (e) { next(e); }
});

app.get("/api/stories", (req, res, next) => {
  try {
    const stories = db.prepare("SELECT id,title,logline,genre,language,created_at,updated_at FROM stories WHERE owner_hash=? ORDER BY updated_at DESC LIMIT 100").all(req.ownerHash);
    res.json({ stories });
  } catch (e) { next(e); }
});
app.post("/api/stories", (req, res, next) => {
  try {
    recordUsage(req.ownerHash, "save", 100, 60 * 60 * 1000);
    const title = requireString(req.body.title, "Title", 200);
    const logline = typeof req.body.logline === "string" ? req.body.logline.slice(0, 2000) : "";
    const genre = typeof req.body.genre === "string" ? req.body.genre.slice(0, 80) : "";
    const language = typeof req.body.language === "string" ? req.body.language.slice(0, 40) : "";
    const story = requireString(req.body.story, "Story", MAX_INPUT_CHARS);
    const metadata = req.body.metadata && typeof req.body.metadata === "object" ? JSON.stringify(req.body.metadata).slice(0, 50000) : "{}";
    const now = new Date().toISOString();
    const id = crypto.randomUUID();
    db.prepare("INSERT INTO stories(id,owner_hash,title,logline,genre,language,story,metadata_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)")
      .run(id, req.ownerHash, title, logline, genre, language, story, metadata, now, now);
    res.status(201).json({ story: { id, title, logline, genre, language, created_at: now, updated_at: now } });
  } catch (e) { next(e); }
});
app.get("/api/stories/:id", (req, res, next) => {
  try {
    const s = db.prepare("SELECT * FROM stories WHERE id=? AND owner_hash=?").get(req.params.id, req.ownerHash);
    if (!s) throw httpError(404, "Story not found.");
    let metadata = {}; try { metadata = JSON.parse(s.metadata_json || "{}"); } catch {}
    res.json({ story: { id: s.id, title: s.title, logline: s.logline, genre: s.genre, language: s.language, story: s.story, metadata, created_at: s.created_at, updated_at: s.updated_at } });
  } catch (e) { next(e); }
});
app.delete("/api/stories/:id", (req, res, next) => {
  try {
    const result = db.prepare("DELETE FROM stories WHERE id=? AND owner_hash=?").run(req.params.id, req.ownerHash);
    if (!result.changes) throw httpError(404, "Story not found.");
    res.json({ ok: true });
  } catch (e) { next(e); }
});

app.use(express.static(path.join(__dirname, "public"), { maxAge: IS_PROD ? "1h" : 0 }));
app.use((err, _req, res, _next) => {
  const status = Number(err.status) || 500;
  if (status >= 500) console.error(err.stack || err.message);
  res.status(status).json({ error: status === 500 ? "An unexpected server error occurred. Please retry." : err.message });
});
app.listen(PORT, () => console.log(`EZStoryByClingyAi listening on http://localhost:${PORT}`));
